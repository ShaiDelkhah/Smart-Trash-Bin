#include "arduino_secrets.h"

#include <Servo.h>

const int ledPin = 12;
const int echoPin = 8;
const int trigPin = 9;
const int servoPin = 10; 

long duration;
int distance_cm;
Servo myServo;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(trigPin, OUTPUT);
  myServo.attach(servoPin);
}

void loop() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(5);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  duration = pulseIn(echoPin, HIGH, 30000);

  if (duration == 0) {
    digitalWrite(ledPin, LOW);
    return;
  }

  distance_cm = (duration * 0.034) / 2;

  if (distance_cm <= 15) {
    digitalWrite(ledPin, HIGH);
  } else {
    digitalWrite(ledPin, LOW);
  }
delay(60);

if (digitalRead(ledPin) == HIGH){
  myServo.write(50);
  delay(2000);
}
else{
  myServo.write(0);
  delay(1000);
}
}